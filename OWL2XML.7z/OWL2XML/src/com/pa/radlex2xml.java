package com.pa;
//� DH Healthcare

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintStream;
import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLAnnotation;
import org.semanticweb.owlapi.model.OWLAnnotationAssertionAxiom;
import org.semanticweb.owlapi.model.OWLAnnotationObjectVisitor;
import org.semanticweb.owlapi.model.OWLAnnotationProperty;
import org.semanticweb.owlapi.model.OWLAnnotationPropertyDomainAxiom;
import org.semanticweb.owlapi.model.OWLAnnotationPropertyRangeAxiom;
import org.semanticweb.owlapi.model.OWLAnnotationValue;
import org.semanticweb.owlapi.model.OWLAnonymousIndividual;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLDataProperty;
import org.semanticweb.owlapi.model.OWLEntity;
import org.semanticweb.owlapi.model.OWLException;
import org.semanticweb.owlapi.model.OWLIndividual;
import org.semanticweb.owlapi.model.OWLLiteral;
import org.semanticweb.owlapi.model.OWLNamedIndividual;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyFormat;
import org.semanticweb.owlapi.model.OWLOntologyManager;
import org.semanticweb.owlapi.model.OWLPropertyAssertionAxiom;
import org.semanticweb.owlapi.model.OWLPropertyAssertionObject;
import org.semanticweb.owlapi.model.OWLSubAnnotationPropertyOfAxiom;
import org.semanticweb.owlapi.model.PrefixManager;
import org.semanticweb.owlapi.reasoner.Node;
import org.semanticweb.owlapi.reasoner.OWLReasoner;
import org.semanticweb.owlapi.reasoner.OWLReasonerFactory;
import org.semanticweb.owlapi.reasoner.structural.StructuralReasonerFactory;
import org.semanticweb.owlapi.util.DefaultPrefixManager;

public class radlex2xml {
	private static abstract class AbstractProcessor {
		private OWLOntologyManager manager;
		private OWLOntology ontology;
		private Map<String, String> idToPreferredNames;

		public final ProcessResult process(CliArgs args) throws Exception {
			// We first need to obtain a copy of an OWLOntologyManager
			manager = OWLManager.createOWLOntologyManager();

			// Now load the ontology.
			ontology = manager.loadOntologyFromOntologyDocument(args.getSrcIRI());

			// Report information about the ontology
			printLineOut("Ontology Loaded...");
			printLineOut("Document IRI: " + args.getSrcIRI());
			printLineOut("Ontology : " + ontology.getOntologyID());
			printLineOut("Format : " + manager.getOntologyFormat(ontology));

			ProcessResult result = processImpl(manager, ontology, args);

			printLineOut("Processing finished (" + result.nProcessed + "/" + result.nTotal + " processed, "
					+ result.nNonTranslated + " non translated, " + result.nIgnored + " ignored)");

			return result;
		}

		protected OWLOntology getOntology() {
			return ontology;
		}

		protected OWLOntologyManager getOntologyManager() {
			return manager;
		}

		protected String valueForClass(OWLClass clazz) {
			return idForEntity(clazz);
		}

		protected Map<Language, String> meaningForClass(OWLClass clazz) {
			if (idToPreferredNames == null) {
				idToPreferredNames = createIdToPreferredNamesMap();
			}

			MeaningExtractor le = new MeaningExtractor(idToPreferredNames.get(idForEntity(clazz)));
			Set<OWLAnnotation> annotations = clazz.getAnnotations(ontology);
			for (OWLAnnotation anno : annotations) {
				anno.accept(le);
			}

			Map<Language, String> result = le.getResult();
			if (result == null || result.isEmpty()) {
				result = Collections.singletonMap(Language.en, clazz.getIRI().toString());
			}

			return result;
		}

		private Map<String, String> createIdToPreferredNamesMap() {
			Set<OWLDataProperty> dps = getOntology().getDataPropertiesInSignature();
			if (dps != null) {
				Map<String, String> map = new HashMap<String, String>();
				for (OWLDataProperty prop : dps) {
					String id = idForEntity(prop);
					if (id != null && "Preferred_Name".equalsIgnoreCase(id)) {

						Set<OWLAxiom> axioms = getOntology().getReferencingAxioms(prop);
						if (axioms != null) {
							for (OWLAxiom axiom : axioms) {
								if (axiom instanceof OWLPropertyAssertionAxiom) {
									OWLIndividual individual = ((OWLPropertyAssertionAxiom<?, ?>) axiom).getSubject();
									OWLPropertyAssertionObject o = ((OWLPropertyAssertionAxiom<?, ?>) axiom)
											.getObject();
									String key = individual instanceof OWLNamedIndividual
											? idForEntity(((OWLNamedIndividual) individual))
											: null;
									String value = o instanceof OWLLiteral ? ((OWLLiteral) o).getLiteral() : null;

									if (key != null && value != null) {

										map.put(key, value);
									}
								}
							}
						}
					}
				}
				return map;
			}
			return Collections.emptyMap();
		}

		protected List<OWLClass> findClasses(OWLReasoner reasoner, String... classes) {
			List<OWLClass> list = new ArrayList<OWLClass>();
			if (classes == null || classes.length == 0) {
				printLineOut("No OWL class specified...using root class ('owl:Thing')"); //$NON-NLS-1$

				list.add(manager.getOWLDataFactory().getOWLThing());
			} else {
				PrefixManager prefixManager = null;

				OWLOntologyFormat format = (OWLOntologyFormat) manager.getOntologyFormat(ontology);
				if (format instanceof PrefixManager) {
					prefixManager = (PrefixManager) format;
				} else {
					prefixManager = new DefaultPrefixManager();
				}

				for (String clazz : classes) {
					try {
						Node<OWLClass> node = reasoner
								.getEquivalentClasses(manager.getOWLDataFactory().getOWLClass(clazz, prefixManager));
						if (node.getSize() > 0) {
							list.add(node.getEntities().iterator().next());

						} else {
							throw new Exception();
						}
					} catch (Exception e) {
						printLineOut("Unable to find OWL class (name: '" + clazz + "')"); //$NON-NLS-1$ //$NON-NLS-2$
					}
				}
			}
			return list;
		}

		protected abstract ProcessResult processImpl(OWLOntologyManager manager, OWLOntology ontology, CliArgs args)
				throws Exception;
	}

	private static class PrintProcessor extends AbstractProcessor {
		private static final int INDENT = 4; // the tab indent when printing the hierarchy

		protected ProcessResult processImpl(OWLOntologyManager manager, OWLOntology ontology, CliArgs args)
				throws Exception {
			ProcessResult result = new ProcessResult();
			OWLReasonerFactory reasonerFactory = new StructuralReasonerFactory();
			OWLReasoner reasoner = null;

			try {
				reasoner = reasonerFactory.createNonBufferingReasoner(ontology);

				List<OWLClass> list = findClasses(reasoner, args.getClasses());
				if (list == null || list.isEmpty()) {

					printLineOut("No OWL class specified or resolved...nothing to print!"); //$NON-NLS-1$
				} else {
					for (OWLClass clazz : list) {
						printHierarchy(System.out, reasoner, clazz, 0, args.getLanguage(),
								args.getOutputNonTranslated(), args.getIngoreClasses(), result);
					}
				}
			} finally {
				if (reasoner != null) {
					reasoner.dispose();
				}
			}

			return result;
		}

		private void printHierarchy(PrintStream stream, OWLReasoner reasoner, OWLClass clazz, int level,
				Language language, boolean outputNonTranslated, String[] ignoreClasses, ProcessResult result)
				throws OWLException {
			result.nTotal++;

			if (!reasoner.isSatisfiable(clazz)
					|| (ignoreClasses != null && Arrays.asList(ignoreClasses).contains(idForEntity(clazz)))) {

				result.nIgnored++;

				return;
			}

			Map<Language, String> meanings = meaningForClass(clazz);
			String meaning = meanings != null ? meanings.get(language) : null;
			if (meaning == null) {
				if (!outputNonTranslated) {

					return;
				}

				result.nNonTranslated++;
				meaning = meanings.get(Language.en);
			}

			for (int i = 0; i < level * INDENT; i++) {
				stream.print(" ");
			}

			stream.println(meaning);

			result.nProcessed++;

			/* Find the children and recurse */
			for (OWLClass child : reasoner.getSubClasses(clazz, true).getFlattened()) {
				if (!child.equals(clazz)) {

					printHierarchy(stream, reasoner, child, level + 1, language, outputNonTranslated, ignoreClasses,
							result);
				}
			}
		}
	}

	private static class ExportProcessor extends AbstractProcessor {
		private static final String DESIGNATOR_ID = "RSNA"; //$NON-NLS-1$
		private static final String DESIGNATOR_NAME = "RSNA"; //$NON-NLS-1$
		private static final String CATALOGUE_ID = "RADLEX"; //$NON-NLS-1$

		protected ProcessResult processImpl(OWLOntologyManager manager, OWLOntology ontology, CliArgs args)
				throws Exception {
			ProcessResult result = new ProcessResult();
			OWLReasonerFactory reasonerFactory = new StructuralReasonerFactory();
			OWLReasoner reasoner = null;
			OutputStreamWriter writer = null;

			try {
				reasoner = reasonerFactory.createNonBufferingReasoner(ontology);

				List<OWLClass> list = findClasses(reasoner, args.getClasses());
				if (list == null || list.isEmpty()) {
					printLineOut("No OWL class specified or resolved...nothing to export!"); //$NON-NLS-1$
				} else {
					printLineOut("Exporting...please wait");

					
					writer = new OutputStreamWriter(new FileOutputStream(args.getTargetFile()), "utf-8");
					
					
					//writer.write("\t<simple_tree>\n");

					for (OWLClass clazz : list) {
						
						exportHierarchy(writer, reasoner, clazz, 0, args.getLanguage(), args.getOutputNonTranslated(),
								args.getIngoreClasses(), result);
					}

					
					//writer.write("\t</simple_tree>\n"); //$NON-NLS-1$
					printLineOut("RADLEX ontology exported to file " + args.getTargetFile());
				}
			} finally {
				if (reasoner != null) {
					reasoner.dispose();
				}
				if (writer != null) {
					try {
						writer.close();
					} catch (Exception e) {
						printError("Unable to close file output stream!", e); //$NON-NLS-1$
					}
				}
			}

			return result;
		}

		private void exportHierarchy(OutputStreamWriter writer, OWLReasoner reasoner, OWLClass clazz, int level,
				Language language, boolean outputNonTranslated, String[] ignoreClasses, ProcessResult result)
				throws OWLException, IOException {
			result.nTotal++;

			if (!reasoner.isSatisfiable(clazz)
					|| (ignoreClasses != null && Arrays.asList(ignoreClasses).contains(idForEntity(clazz)))) {
				result.nIgnored++;

				return;
			}

			try {
				StringBuilder sbuilder = new StringBuilder();
				for (int i = 0; i < level + 2; i++) {
					sbuilder.append("\t"); //$NON-NLS-1$
				}

				Map<Language, String> meanings = meaningForClass(clazz);
				String meaning = meanings != null ? meanings.get(language) : null;

				if (meaning == null) {
					if (!outputNonTranslated) {

						return;
					}

					result.nNonTranslated++;
					meaning = meanings.get(Language.en);
				}
				System.out.println("menaing : > " + meaning);
				writer.write(escapeXML(sbuilder.toString()));
				writer.write("<class Key=\"");
				writer.write(escapeXML(valueForClass(clazz)));
				writer.write("\" title=\"");
				writer.write(escapeXML(meaning));
				writer.write("\">");

				result.nProcessed++;

				/* Find the children and recurse */
				Set<OWLClass> set = reasoner.getSubClasses(clazz, true).getFlattened();

				if (set != null && set.size() > 0) {

					writer.write("\n"); //$NON-NLS-1$
					for (OWLClass child : set) {

						if (!child.equals(clazz)) {

							exportHierarchy(writer, reasoner, child, level + 1, language, outputNonTranslated,
									ignoreClasses, result);

						}
					}

					writer.write(sbuilder.toString());
				}
				writer.write("</class>\n"); //$NON-NLS-1$
			} catch (IOException e) {
				printLineOut("Unable to export class ('" + clazz + "')"); //$NON-NLS-1$ //$NON-NLS-2$
			}
		}

		private String escapeXML(String s) {
			s = s.replaceAll("&", "&amp;"); //$NON-NLS-1$ //$NON-NLS-2$
			s = s.replaceAll("\"", "&quot;"); //$NON-NLS-1$ //$NON-NLS-2$
			s = s.replaceAll("\'", "&apos;"); //$NON-NLS-1$ //$NON-NLS-2$
			s = s.replaceAll("<", "&lt;"); //$NON-NLS-1$ //$NON-NLS-2$
			s = s.replaceAll(">", "&gt;"); //$NON-NLS-1$ //$NON-NLS-2$
			return s;
		}
	}

	@SuppressWarnings("javadoc")
	public static void main(String[] args) throws MalformedURLException, OWLException, InstantiationException,
			IllegalAccessException, ClassNotFoundException {
		if (args == null || args.length == 0 || args[0].contains("help") || args[0].contains("?")) {
			printUsage();
			System.exit(0);
		}

		CliArgs cliArgs = null;

		try {
			// parse command line arguments
			cliArgs = CliArgs.parse(args);
		} catch (Exception e) {
			printError(null, e);
			printUsage();

			System.exit(1);
		}

		try {
			// it's likely that we need to increase the default limitation of
			// supported entities per ontology within OWL API
			String s = System.getProperty("entityExpansionLimit"); //$NON-NLS-1$
			if (s == null) {
				System.setProperty("entityExpansionLimit", "128000"); //$NON-NLS-1$ //$NON-NLS-2$
			}

			// do the work
			cliArgs.getOperation().process(cliArgs);
		} catch (Exception e) {
			printError(null, e);
			System.exit(1);
		}
	}

	private static String idForEntity(OWLEntity entity) {
		String fragment = entity.getIRI().getFragment();
		if (fragment != null) {
			return fragment;
		}

		return entity.toStringID();
	}

	private static void printUsage() {
		printLineOut("Converts a radlex source file (*.owl) into XML format");
		printLineOut("which can be further processed by ImpaxEE R20/Web clients.");
		printLineOut("Please make sure to use the radlex light version (dl) - the");
		printLineOut("full version isn't supported yet");
		printLineOut("For an online RADLEX browser see http://www.radlex.org");
		printLineOut("----------------------------------------------------------");
		printLineOut("Usage: radlex2xml op={operation} source={filepath} lang={en|de}");
		printLineOut("                  version={version} nontranslated={true|false}");
		printLineOut("                  root-classes={class-id,...,class-id}");
		printLineOut("                  ignore-classes={class-id,...,class-id}");
		printLineOut("   operation: (optional, the default is export)");
		printLineOut("      print: prints whole or parts of the RADLEX ontology to the console");
		printLineOut("      export: exports whole or parts of the RADLEX ontology to XML so it");
		printLineOut("              can be processed by ImpaxEE R20/WEB clients");
		printLineOut("   lang: either en or de (optional; by default - the primary language of the");
		printLineOut("         supplied *.owl file is used)");
		printLineOut("   nontranslated: if true, terms that couldn't be translated into the preferred");
		printLineOut("                  language are going to be printed/exported in english;");
		printLineOut("                  if false, non-translated terms are going to be ommited");
		printLineOut("                  (optional, the default is true)");
		printLineOut("   version: specifies the version suffix of the RADLEX source (optional; by");
		printLineOut("            default, this is an empty string - so that the version is ommited)");
		printLineOut("   source: the path of the RADLEX source file (*.owl)");
		printLineOut("   root-classes: an optional list of comma-separated (,) OWL class-id's that");
		printLineOut("            shall be printed/exported. If no class is specified the whole RADLEX");
		printLineOut("            ontology/class hierarchy beginning at the root class (i.e 'thing')"); //$NON-NLS-1$
		printLineOut("            is being printed/exported; examples of the most important class-ids");
		printLineOut("            are:");
		printLineOut("            RID13390....'anatomical structure'");
		printLineOut("            RID3........'anatomical entity'");
		printLineOut("            RID5........'imaging observation'");
		printLineOut("            There's a RADLEX online browser (www.radlex.org) in order to");
		printLineOut("            query for suitable class-ids");
		printLineOut("   ignore-classes: an optional list of comma-separated (,)");
		printLineOut("                   OWL class-id's which shall be ignored in");
		printLineOut("                   the final output");
	}

	private static void printLineOut(Object o) {
		PrintStream stream = System.out;
		stream.println(o);
	}

	private static void printError(String s, Exception e) {
		PrintStream stream = System.err;

		if (s != null) {
			stream.println(s);
		}

		e.printStackTrace(stream);
	}

	public static class MeaningExtractor implements OWLAnnotationObjectVisitor {
		Map<Language, String> result;

		public MeaningExtractor() {
			this(null);
		}

		public MeaningExtractor(String preferredMeaning) {
			if (preferredMeaning != null) {
				addResult(preferredMeaning, Language.en);
			}
		}

		public void visit(OWLAnonymousIndividual individual) {
		}

		public void visit(IRI iri) {
		}

		public void visit(OWLLiteral literal) {
		}

		public void visit(OWLAnnotation annotation) {
			OWLAnnotationProperty prop = annotation.getProperty();
			String id = idForEntity(prop);

			if (annotation.getProperty().isLabel()) {
				OWLLiteral c = (OWLLiteral) annotation.getValue();
				Language lang = getLanguage(c);
				if (result == null || !result.containsKey(lang)) {
					addResult(c.getLiteral(), getLanguage(c));
				}
			}

			if ("Preferred_name_German".equalsIgnoreCase(id)) {
				OWLLiteral c = (OWLLiteral) annotation.getValue();
				addResult(c.getLiteral(), c.hasLang() ? getLanguage(c) : Language.de);
			}

			if ("Preferred_name".equalsIgnoreCase(id)) {
				OWLLiteral c = (OWLLiteral) annotation.getValue();
				addResult(c.getLiteral(), getLanguage(c));
			}
		}

		public void visit(OWLAnnotationAssertionAxiom axiom) {
			OWLAnnotationProperty prop = axiom.getProperty();
			String id = idForEntity(prop);
			if ("Preferred_name".equalsIgnoreCase(id)) {
				OWLLiteral c = (OWLLiteral) axiom.getValue();
				addResult(c.getLiteral(), getLanguage(c));
			}
		}

		public void visit(OWLAnnotationPropertyDomainAxiom axiom) {
		}

		public void visit(OWLAnnotationPropertyRangeAxiom axiom) {
		}

		public void visit(OWLSubAnnotationPropertyOfAxiom axiom) {
		}

		public void visit(OWLAnnotationProperty property) {
		}

		public void visit(OWLAnnotationValue value) {
		}

		private Language getLanguage(OWLLiteral literal) {
			if (literal.hasLang(Language.de.name())) {
				return Language.de;
			}
			return Language.en;
		}

		private void addResult(String text, Language lang) {
			if (result == null) {
				result = new HashMap<Language, String>(2);
			}
			result.put(lang, text);
		}

		public Map<Language, String> getResult() {
			return result;
		}
	}

	private static class ProcessResult {
		private int nTotal = 0;
		private int nProcessed = 0;
		private int nNonTranslated = 0;
		private int nIgnored = 0;
		public boolean selectable = false;
	}

	private static enum Operation {
		print(new PrintProcessor()), export(new ExportProcessor());

		private AbstractProcessor processor;

		private Operation(AbstractProcessor processor) {
			this.processor = processor;
		}

		public ProcessResult process(CliArgs args) throws Exception {
			return processor.process(args);
		}
	}

	private static enum Language {
		en, de
	}

	private static class CliArgs {
		public static CliArgs parse(String[] args) throws Exception {
			// build arg map
			Map<String, String> argsMap = new HashMap<String, String>();
			if (args != null) {
				for (String s : args) {
					String[] pair = s.split("="); //$NON-NLS-1$
					argsMap.put(pair[0].trim(), pair[1].trim());
				}
			}

			// operation
			Operation op = argsMap.containsKey("op") ? Operation.valueOf(argsMap.get("op")) : Operation.export;

			// language
			Language lang = argsMap.containsKey("lang") ? Language.valueOf(argsMap.get("lang")) : Language.en;

			// non-translated
			boolean nonTranslated = argsMap.containsKey("nontranslated")
					? Boolean.parseBoolean(argsMap.get("nontranslated"))
					: true;

			// version
			String version = argsMap.get("version");

			// source file
			File srcFile = new File(argsMap.get("source"));

			// target file
			File targetFile = inferTargetFileFromSourceFile(srcFile);

			// ontology class names/identifiers (i.e rdf:id)
			String[] classes = argsMap.containsKey("root-classes") ? argsMap.get("root-classes").split(",") : null;

			// ontology class names/identifiers (i.e rdf:id)
			String[] ignoreClasses = argsMap.containsKey("ignore-classes") ? argsMap.get("ignore-classes").split(",")
					: null;

			return new CliArgs(op, srcFile, targetFile, version, lang, nonTranslated, classes, ignoreClasses);
		}

		private static File inferTargetFileFromSourceFile(File src) {
			String fileName = src.getName();

			if (fileName.contains(".")) //$NON-NLS-1$
			{
				fileName = fileName.substring(0, fileName.lastIndexOf(".")); //$NON-NLS-1$
			}
			if (!fileName.endsWith(".xml")) //$NON-NLS-1$
			{
				fileName += ".xml"; //$NON-NLS-1$
			}

			return new File(System.getProperty("user.dir"), fileName);
		}

		public Operation getOperation() {
			return operation;
		}

		public String getVersionSuffix() {
			return version;
		}

		public IRI getSrcIRI() {
			return srcIRI;
		}

		public File getTargetFile() {
			return targetFile;
		}

		public String[] getClasses() {
			return classes;
		}

		public String[] getIngoreClasses() {
			return ignoreClasses;
		}

		public Language getLanguage() {
			return language;
		}

		public boolean getOutputNonTranslated() {
			return outputNonTranslated;
		}

		private Operation operation;
		private String version;
		private IRI srcIRI;
		private String[] classes;
		private String[] ignoreClasses;
		private Language language;
		private File targetFile;
		private boolean outputNonTranslated;

		private CliArgs(Operation operation, File srcFile, File targetFile, String version, Language lang,
				boolean outputNonTranslated, String[] classes, String... ignoreClasses) {
			this.operation = operation;
			this.version = version;
			this.srcIRI = IRI.create(srcFile);
			this.classes = classes;
			this.ignoreClasses = ignoreClasses;
			this.language = lang;
			this.targetFile = targetFile;
			this.outputNonTranslated = outputNonTranslated;
		}
	}
}