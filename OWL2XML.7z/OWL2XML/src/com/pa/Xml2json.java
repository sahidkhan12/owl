package com.pa;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import org.json.JSONObject;
import org.json.XML;

public class Xml2json {

    static String line="",str="";
    public static void main(String[] args) throws Exception, IOException {
        String link = "C:\\Users\\shahidk\\Documents\\OWL\\RadLex_Xml\\RadLex.xml";
        BufferedReader br = new BufferedReader(new FileReader(link));
        while ((line = br.readLine()) != null) 
        {   
            str+=line;  
        }
        JSONObject jsondata = XML.toJSONObject(str);
        FileWriter fileWriter =
                new FileWriter("C:\\Users\\shahidk\\Documents\\OWL\\Json_data\\RadLex_EN.json");

            // Always wrap FileWriter in BufferedWriter.
            BufferedWriter bufferedWriter =
                new BufferedWriter(fileWriter);
           
            // Always close files.
            bufferedWriter.write(jsondata.toString());  

           
            bufferedWriter.close();
            System.out.println("done : ");
        }

}