package com.pa;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Children implements Serializable {
	  private String title;

	    @JsonProperty("Key")
	    private String key;

	    private boolean selectable =true;
	    
	    private boolean IsExpandable;
	    
	    private boolean IsLeaf=true;
	    
	    public boolean isSelectable() {
			return selectable;
		}
		public void setSelectable(boolean selectable) {
			this.selectable = selectable;
		}
		
		
		public boolean isIsExpandable() {
			return IsExpandable;
		}
		public void setIsExpandable(boolean isExpandable) {
			IsExpandable = isExpandable;
		}
		
		
		public boolean isIsLeaf() {
			return IsLeaf;
		}
		public void setIsLeaf(boolean isLeaf) {
			IsLeaf = isLeaf;
		}


		@JsonProperty("class")
		private List<Children> children;

	    public void setTitle(String title){
	        this.title = title;
	    }
	    public String getTitle(){
	        return this.title;
	    }
	    public void setKey(String key){
	        this.key = key;
	    }
	    public String getKey(){
	        return this.key;
	    }
	    public void setChildren(List<Children> children){
	    	if(children==null|| children.isEmpty())
	    	{
	    		IsLeaf=true;
	    		selectable=true;
	    		IsExpandable=false;
	    		
	    	}	
	    	else
	    	{
	    		selectable=false;
	    		IsExpandable=true;
	    		IsLeaf=false;
	    	}	
	        this.children = children;
	    }
	    public List<Children> getChildren(){
	        return this.children;
	    }
		
	    
}
