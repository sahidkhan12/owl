package com.pa;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

import org.json.JSONObject;
import org.json.XML;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

public class Xml2json1 {

    static String line="",str="";
    public static void main(String[] args) throws Exception, IOException {
        String link = "C:\\Users\\shahidk\\Documents\\OWL\\RadLex_Xml\\Expected_Data\\RadLex.xml";
        BufferedReader br = new BufferedReader(new FileReader(link));
        while ((line = br.readLine()) != null) 
        {   
            str+=line;  
        }
        JSONObject jsondata = XML.toJSONObject(str);
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.configure(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
 
        Root car = objectMapper.readValue(jsondata.toString(), Root.class);	


        JSONObject jsonData = new JSONObject(car);
        
      //  System.out.println("data: > "+jsonData.toString());
//         objectMapper.readValue(link, null);
        
        FileWriter fileWriter =
                new FileWriter("C:\\Users\\shahidk\\Documents\\OWL\\RadLex_Xml\\Expected_Data\\Imaging_Specialty_DE.json");

            // Always wrap FileWriter in BufferedWriter.
            BufferedWriter bufferedWriter =
                new BufferedWriter(fileWriter);
           
            // Always close files.
            bufferedWriter.write(jsonData.toString());  

           
            bufferedWriter.close();
            System.out.println("done : ");
        }

}